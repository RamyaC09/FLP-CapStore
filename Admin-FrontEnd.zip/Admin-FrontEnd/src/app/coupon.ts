import { OrderedItem } from './ordered-item';

export class Coupon {
    coupCode:string;
    discount:number;
}
