import { Component, OnInit } from '@angular/core';
import { MerchantReport } from '../merchant-report';
import { AdminServiceService } from '../admin-service.service';


@Component({
  selector: 'app-merchantreport',
  templateUrl: './merchantreport.component.html',
  styleUrls: ['./merchantreport.component.css']
})
export class MerchantreportComponent implements OnInit {

  productCategory: String;
  units: number;
  report = new MerchantReport();

  constructor(private businessService: AdminServiceService) { }

  ngOnInit() {
    this.businessService.getMerchantReport().subscribe((report) => {
      this.report = (report);
      console.log(report);
      console.log(this.report);
    }
    )
  }

}
