import { Product } from './product';

export class ProductRating {
    ratId:string;
    product:Product;
    currRating:number;
    ratingCount:number;
}
