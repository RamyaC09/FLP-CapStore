import { Component, OnInit } from '@angular/core';
import { OrderedItem } from '../ordered-item';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-placed-products',
  templateUrl: './placed-products.component.html',
  styleUrls: ['./placed-products.component.css']
})
export class PlacedProductsComponent implements OnInit {
  capstore: OrderedItem[];

  constructor(private capStoreService:AdminServiceService) { }

  ngOnInit() {
    this.capStoreService.showPlacedProducts().subscribe(response=>this.handleSuccessfulResponse(response));
  }
  handleSuccessfulResponse(response){
    this.capstore=response;
    console.log(this.capstore);
  }
updatePldStatus(productOrdId: string,productOrdStatus: string){
  this.capStoreService.updatePld(productOrdId,productOrdStatus).subscribe(data => {
  this.capstore = data;
  });
}}
