import { MerchantReport } from './merchant-report';

describe('MerchantReport', () => {
  it('should create an instance', () => {
    expect(new MerchantReport()).toBeTruthy();
  });
});
