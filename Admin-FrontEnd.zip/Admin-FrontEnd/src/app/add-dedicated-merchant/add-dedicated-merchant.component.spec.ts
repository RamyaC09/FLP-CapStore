import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDedicatedMerchantComponent } from './add-dedicated-merchant.component';

describe('AddDedicatedMerchantComponent', () => {
  let component: AddDedicatedMerchantComponent;
  let fixture: ComponentFixture<AddDedicatedMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddDedicatedMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDedicatedMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
