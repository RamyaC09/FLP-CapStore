import { Component, OnInit } from '@angular/core';
import { OrderedItem } from '../ordered-item';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-ordered-products',
  templateUrl: './ordered-products.component.html',
  styleUrls: ['./ordered-products.component.css']
})
export class OrderedProductsComponent implements OnInit {
  capstore: OrderedItem[];
  capstore2:OrderedItem[];

  constructor(private adminService:AdminServiceService) { }

  ngOnInit() {
    this.adminService.showAllOrderedProducts().subscribe(response=>this.handleSuccessfulResponse(response));
  }
  handleSuccessfulResponse2(response){
    this.capstore2=response;
    console.log(this.capstore2);    
  }

    handleSuccessfulResponse(response){
      this.capstore=response;
      this.adminService.getProducts();
    }
updateProduct(productOrdId: string,productOrdStatus: string){
  this.adminService.updateProduct(productOrdId,productOrdStatus).subscribe(data => {
    this.capstore = data;
    console.log(this.capstore)
});
}
}
