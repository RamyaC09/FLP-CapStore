export class Delivery {
    ordId: number;
    dateOfOrd: Date;
    noOfDaysForDelivery: number;
    status: String

}