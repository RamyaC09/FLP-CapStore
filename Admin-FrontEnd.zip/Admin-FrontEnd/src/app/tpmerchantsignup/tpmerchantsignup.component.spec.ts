import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TpmerchantsignupComponent } from './tpmerchantsignup.component';

describe('TpmerchantsignupComponent', () => {
  let component: TpmerchantsignupComponent;
  let fixture: ComponentFixture<TpmerchantsignupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TpmerchantsignupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TpmerchantsignupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
