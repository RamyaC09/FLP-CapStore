import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddThirdPartyMerchantComponent } from './add-third-party-merchant.component';

describe('AddThirdPartyMerchantComponent', () => {
  let component: AddThirdPartyMerchantComponent;
  let fixture: ComponentFixture<AddThirdPartyMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddThirdPartyMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddThirdPartyMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
