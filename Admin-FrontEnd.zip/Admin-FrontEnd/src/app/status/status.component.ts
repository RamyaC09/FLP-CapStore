// import { Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-status',
//   templateUrl: './status.component.html',
//   styleUrls: ['./status.component.css']
// })
// export class StatusComponent implements OnInit {

//   constructor() { }

//   ngOnInit() {
//   }

// }
import { Component, OnInit } from '@angular/core';
import { Delivery } from '../delivery';
import { AdminServiceService } from '../admin-service.service';



@Component({
    selector: 'app-status',
    templateUrl: './status.component.html',
    styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {

tracking=new Delivery();

    constructor(private service: AdminServiceService) {

    }

    ngOnInit() {

    }
    check(data) {
        this.service.proStatus(data.ordId).subscribe(data => this.tracking = data);
        console.log(data);
    }
}