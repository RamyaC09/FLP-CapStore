import { Component, OnInit } from '@angular/core';
import { OrderedItem } from '../ordered-item';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-dispatched-products',
  templateUrl: './dispatched-products.component.html',
  styleUrls: ['./dispatched-products.component.css']
})
export class DispatchedProductsComponent implements OnInit {
  capstore: OrderedItem[];

  constructor(private capStoreService:AdminServiceService) { }

  ngOnInit() {
    this.capStoreService.showDispatchedProducts().subscribe(response=>this.handleSuccessfulResponse(response));
   
  }
  handleSuccessfulResponse(response){
    this.capstore=response;
    
}
    
  updateDispStatus(productOrdId: string,productOrdStatus: string){
    this.capStoreService.updateDisp(productOrdId,productOrdStatus).subscribe(data => {
      this.capstore = data;
  });
}
}
