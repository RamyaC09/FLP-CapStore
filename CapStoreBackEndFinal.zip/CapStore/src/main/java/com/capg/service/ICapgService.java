package com.capg.service;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import com.capg.bean.CartItem;
import com.capg.bean.Coupon;
import com.capg.bean.Customer;
import com.capg.bean.Email;
import com.capg.bean.Feedback;
import com.capg.bean.Merchant;
import com.capg.bean.MerchantFeedback;
import com.capg.bean.OrderedItem;
import com.capg.bean.Product;
import com.capg.bean.Rating;
import com.capg.bean.Transaction;
import com.capg.bean.WishItem;

public interface ICapgService {

	public List<Transaction> insertTransaction(Transaction transaction);
	public void updateRevenue(int cvv, int amount);
	public void registerCustomer(Customer customer, String password) throws Exception;
	public Customer findCustomerById(String custId);
	public void addCustomerWish(String custId, WishItem wish);
	public void registerMerchant(Merchant merchant, String password);
	public Customer loginCustomer(String email, String password) throws RuntimeException;
	public Merchant loginMerchant(String email, String password) throws RuntimeException;
	public String encryptPassword(String pass) throws NoSuchAlgorithmException;
	public List<Product> getAllProducts();
	public List<Product> getThirdPartyProducts();
	public List<Product> getProductByPriceRange(double min, double max);
	public List<Product> getProductByRating(double rate);
	public Product addMerchantProduct(Product product);
	public List<Product> getMerchantProductsById(String mid);
	public List<OrderedItem> getMerchantOrdersById(String id);
	public void updateMerchantProduct(Product product);
	public void sendMail(Email maildata);
	public List<Email> inbox(String emailId);
	public List<Email> sentBox(String emailId);
	public List<Customer> getCustomersByMerchant(String merId);
	public void updateCustomer(Customer updatedCustomer, String custId);
	public List<OrderedItem> getOrderedItemsByCustId();
	public List<WishItem> getWishListByCustomerId(String custId);
	public void updateCustomerDeposit(Customer customer);
	public void addtoCart(String custId, CartItem cart);
	public List<CartItem> getCartProducts(String custId);
	public List<CartItem> deleteFromCart(String cartId);
	public void addtoWishList(WishItem wish);
	public void addwishtoCart(String custId, CartItem cart);
	public List<WishItem> getWishListById(String custid);
	public List<WishItem> deleteWish(String wishId);
	public void updateInventory(String ordId);
	public OrderedItem getById(String ordId);
	public List<OrderedItem> getListByCust(String id);
	public Customer getCustomerById(String custId);
	public Product getProductById(String id);
	public Product getProductDetailsById(String id);
	public Coupon getCouponByCustomId(String customCouponCode) throws RuntimeException;
	public OrderedItem printInvoice(String orderId);
	public void addtoCart(String custId, Product cart);
	public List<Product> getProductByCategory(String prodCategory);
	public List<Rating> customerProductRating(Rating rating);
	public List<Feedback> customerProductFeedback(Feedback product2);
	public MerchantFeedback sendmerchantresponse(long merchantId, String merchantresponse);
	public String getAllFeedbacks(long merchantId);
	public int changePwd(String id, String password, String newpassword, String confirmpassword);
}
