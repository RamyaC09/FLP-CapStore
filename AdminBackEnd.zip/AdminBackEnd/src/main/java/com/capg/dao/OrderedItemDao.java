package com.capg.dao;

import org.hibernate.validator.constraints.pl.REGON;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.capg.bean.OrderedItem;

@Repository
public interface OrderedItemDao extends JpaRepository<OrderedItem,String>{
	
	@Query("select SUM(ordPrice) from OrderedItem")
	public double totalRevenue();

}
