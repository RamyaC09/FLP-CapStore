package com.capg.bean;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "trackings")
public class Delivery {
	@Id
	private int ordId;
	private Date dateOfOrd;
	private int noOfDaysForDelivery;
	private String status;

	public Delivery() {
		super();
	}

	public Delivery(int ordId, Date dateOfOrd, int noOfDaysForDelivery, String status) {
		super();
		this.ordId = ordId;
		this.dateOfOrd = dateOfOrd;
		this.noOfDaysForDelivery = noOfDaysForDelivery;
		this.status = status;
	}

	public int getOrdId() {
		return ordId;
	}

	public void setOrdId(int ordId) {
		this.ordId = ordId;
	}

	public Date getDateOfOrd() {
		return dateOfOrd;
	}

	public void setDateOfOrd(Date dateOfOrd) {
		this.dateOfOrd = dateOfOrd;
	}

	public int getNoOfDaysForDelivery() {
		return noOfDaysForDelivery;
	}

	public void setNoOfDaysForDelivery(int noOfDaysForDelivery) {
		this.noOfDaysForDelivery = noOfDaysForDelivery;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Delivery [ordId=" + ordId + ", dateOfOrd=" + dateOfOrd + ", noOfDaysForDelivery=" + noOfDaysForDelivery
				+ ", status=" + status + "]";
	}

}
